@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Launcher\AeroStudio-Single.ps1" -App AeroFilm
if errorlevel 1 pause
