﻿AeroFilm individual launcher
Double-click AeroFilm.cmd to download, install or launch AeroFilm Studio.
This downloader verifies the official release with the SHA-256 fingerprint embedded in Launcher\releases.json.
